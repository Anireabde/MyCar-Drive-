MyCar Drive — مشروع Android أولي

شنو كيدير:
- تطبيق Android أصلي بواجهة أفقية بسيطة.
- أزرار كتفتح Waze وDeezer وYouTube وGoogle Maps وWhatsApp إذا كانت مثبتة.
- إذا التطبيق ما كانش مثبت، كيفتح الموقع المرتبط به.

حدود النسخة 1.0:
- هادي Launcher/Dashboard، ماشي Android Auto ولا CarPlay رسمي.
- ما كتدمجش واجهات Waze وDeezer داخل نفس الشاشة، وما فيهاش تحكم موسيقي عميق أو مساعد صوتي.
- YouTube خاصو يبقى للاستعمال والسيارة واقفة.
- APK الناتج من GitHub Actions هو Debug APK للتجربة، ماشي إصدار متجر موقّع للنشر.

بناء APK من الهاتف:
1) أنشئ حساب GitHub إذا ما عندكش، ثم أنشئ Repository جديد باسم MyCarDrive.
2) ارفع جميع محتويات هذا المجلد إلى المستودع (بما فيها .github).
3) افتح تبويب Actions ووافق على تفعيل GitHub Actions إذا طلب منك.
4) شغّل workflow: Build MyCar Drive APK.
5) بعد نجاح البناء، افتح نتيجة التشغيل ونزّل Artifact باسم MyCarDrive-debug-apk.
6) فك ضغط الملف وثبّت app-debug.apk، واسمح بالتثبيت من هذا المصدر إذا طلب Android.

المتطلبات: بناء المشروع يستخدم Android Gradle Plugin 8.7.3 وGradle 8.9 وJDK 17.
