package com.mycardrive.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 23)
    private val panel = Color.rgb(20, 31, 47)
    private val white = Color.WHITE
    private lateinit var clock: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        buildScreen()
        val handler = android.os.Handler(mainLooper)
        val tick = object : Runnable {
            override fun run() {
                clock.text = SimpleDateFormat("HH:mm  •  EEEE, d MMM", Locale.getDefault()).format(Date())
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(tick)
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 16, 22, 16)
            setBackgroundColor(bg)
        }
        val brand = TextView(this).apply {
            text = "MYCAR DRIVE"
            textSize = 15f
            setTextColor(Color.rgb(145, 183, 229))
            gravity = Gravity.CENTER_VERTICAL
        }
        outer.addView(brand, LinearLayout.LayoutParams(-1, 38))

        clock = TextView(this).apply {
            text = "--:--"
            textSize = 27f
            setTextColor(white)
            gravity = Gravity.CENTER_VERTICAL
        }
        outer.addView(clock, LinearLayout.LayoutParams(-1, 54))

        val hint = TextView(this).apply {
            text = "Your drive, your dashboard"
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        outer.addView(hint, LinearLayout.LayoutParams(-1, 30))

        val grid = GridLayout(this).apply { columnCount = 3; rowCount = 2 }
        val items = listOf(
            Triple("🧭  Waze", "com.waze", "https://waze.com/ul"),
            Triple("🎵  Deezer", "deezer.android.app", "https://www.deezer.com/"),
            Triple("▶  YouTube", "com.google.android.youtube", "https://www.youtube.com/"),
            Triple("🗺  Maps", "com.google.android.apps.maps", "https://maps.google.com/"),
            Triple("💬  WhatsApp", "com.whatsapp", "https://wa.me/"),
            Triple("🌐  Browser", "", "https://www.google.com/")
        )
        items.forEach { (label, pkg, url) ->
            val button = Button(this).apply {
                text = label
                textSize = 17f
                isAllCaps = false
                setTextColor(white)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
                setOnClickListener { launch(pkg, url) }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(7, 7, 7, 7)
            }
            grid.addView(button, lp)
        }
        outer.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        val note = TextView(this).apply {
            text = "Use only when safely parked. Waze, Deezer and YouTube open in their own apps."
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        outer.addView(note, LinearLayout.LayoutParams(-1, 34))
        setContentView(outer)
    }

    private fun launch(packageName: String, url: String) {
        try {
            val intent = if (packageName.isNotEmpty()) packageManager.getLaunchIntentForPackage(packageName) else null
            if (intent != null) startActivity(intent)
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
}
